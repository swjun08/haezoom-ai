export const samples = [
  {
    text: '가을 현장체험학습 안내\n2026년 11월 12일까지 참가 신청서를 담임 선생님께 제출해 주세요. 참가비는 15,000원이며 도시락과 물을 준비해 주세요. 체험학습은 11월 18일 오전 9시에 진행합니다.',
    result: {
      summary:
        '현장체험학습 참가 신청서를 11월 12일까지 제출해야 해요. 참가비는 15,000원이며 도시락과 물을 준비해 주세요. 행사 연도는 원문 확인이 필요해요.',
      tasks: [
        {
          title: '현장체험학습 신청서 제출',
          action: '담임 선생님께 참가 신청서를 제출해 주세요.',
          deadline: '2026-11-12',
          materials: ['참가 신청서', '도시락', '물'],
          cost: 15000,
          submission: '담임 선생님',
          evidence: '2026년 11월 12일까지 참가 신청서를 담임 선생님께 제출',
          needs_review: false,
        },
      ],
      schedules: [
        {
          title: '가을 현장체험학습',
          date: '11월 18일',
          time: '오전 9시',
          location: null,
          details: '체험학습 참여 · 연도 확인 필요',
          evidence: '체험학습은 11월 18일 오전 9시에 진행',
          needs_review: true,
        },
      ],
    },
  },
  {
    text: '동아리 발표 신청\n2026-11-15까지 학생회 이메일로 발표 자료를 제출해 주세요. 비용은 없습니다.',
    result: {
      summary: '11월 15일까지 학생회 이메일로 발표 자료를 보내 주세요.',
      tasks: [
        {
          title: '발표 자료 제출',
          action: '학생회 이메일로 보내기',
          deadline: '2026-11-15',
          materials: ['발표 자료'],
          cost: 0,
          submission: '학생회 이메일',
          evidence: '2026-11-15까지 학생회 이메일로 발표 자료를 제출',
          needs_review: false,
        },
      ],
      schedules: [],
    },
  },
  {
    text: '급식실 공사 안내\n2026년 11월 20일부터 11월 22일까지 급식실을 사용하지 않습니다.',
    result: {
      summary: '급식실 공사 기간을 확인해 주세요. 신청하거나 제출할 일은 없어요.',
      tasks: [],
      schedules: [
        {
          title: '급식실 공사',
          date: '2026-11-20 ~ 2026-11-22',
          time: null,
          location: '급식실',
          details: '급식실 사용 불가',
          evidence: '2026년 11월 20일부터 11월 22일까지',
          needs_review: true,
        },
      ],
    },
  },
  {
    text: '학생 상담 신청\n희망자는 다음 주 금요일까지 상담 신청서를 제출해 주세요.',
    result: {
      summary: '상담 신청서를 제출해야 해요. 발행일을 알 수 없어 정확한 날짜 확인이 필요해요.',
      tasks: [
        {
          title: '상담 신청서 제출',
          action: '신청서를 제출해 주세요',
          deadline: '다음 주 금요일',
          materials: ['상담 신청서'],
          cost: null,
          submission: null,
          evidence: '다음 주 금요일까지 상담 신청서를 제출',
          needs_review: true,
        },
      ],
      schedules: [],
    },
  },
  {
    text: '도서관 이용 안내\n운영 시간은 평일 오전 9시부터 오후 5시입니다. 조용히 이용해 주세요.',
    result: {
      summary: '도서관 운영 시간 안내예요. 별도의 할 일이나 날짜가 있는 일정은 없어요.',
      tasks: [],
      schedules: [],
    },
  },
];
