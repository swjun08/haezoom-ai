export const HAEZOOM_API_BASE_URL = 'https://haezoom.sleepwhale.workers.dev';
